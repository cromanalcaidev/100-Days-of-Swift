import UIKit

/*
 
 
 Calculate the number of grains of wheat on a chessboard given that the number on each square doubles.

 There once was a wise servant who saved the life of a prince. The king promised to pay whatever the servant could dream up. Knowing that the king loved chess, the servant told the king he would like to have grains of wheat. One grain on the first square of a chess board, with the number of grains doubling on each successive square.

 There are 64 squares on a chessboard (where square 1 has one grain, square 2 has two grains, and so on).

 Write code that shows:

 how many grains were on a given square, and
 the total number of grains on the chessboard
 
 
 */



func returnGrain (_ num: Int) -> String {
    var totalGrains: Int = 0
    var myArr: [Int] = []
    
    for i in 1...16 {
        if i == 1 {
            totalGrains += 1
        } else {
            totalGrains *= 2
        }
        myArr.append(totalGrains)
        }
    
    
    return "\(totalGrains) and \(myArr[num-1]) and \(myArr)"

}

print(returnGrain(3))




/*
 
 Reverse a given string
 
 */

func reverseString(_ input: String) -> String {
    var output: String = ""
    
    for char in input.reversed() {
        output += String(char)
    }
    return output
}




/*
 
 Each of us inherits from our biological parents a set of chemical instructions known as DNA that influence how our bodies are constructed. All known life depends on DNA!

 Note: You do not need to understand anything about nucleotides or DNA to complete this exercise.

 DNA is a long chain of other chemicals and the most important are the four nucleotides, adenine, cytosine, guanine and thymine. A single DNA chain can contain billions of these four nucleotides and the order in which they occur is important! We call the order of these nucleotides in a bit of DNA a "DNA sequence".

 We represent a DNA sequence as an ordered collection of these four nucleotides and a common way to do that is with a string of characters such as "ATTACG" for a DNA sequence of 6 nucleotides. 'A' for adenine, 'C' for cytosine, 'G' for guanine, and 'T' for thymine.

 Given a string representing a DNA sequence, count how many of each nucleotide is present. If the string contains characters that aren't A, C, G, or T then it is invalid and you should signal an error.

 For example:

 "GATTACA" -> 'A': 3, 'C': 1, 'G': 1, 'T': 2
 "INVALID" -> error
 
 */

func DNA (input: String) -> String {
    
    var countA = 0
    var countC = 0
    var countG = 0
    var countT = 0
    var countErr = 0
    
    for char in input {
        switch char {
        case "A":
            countA += 1
        case "C":
            countC += 1
        case "G":
            countG += 1
        case "T":
            countT += 1
        default:
            countErr += 1
        }
    }
    
    
    return "Your sequence contains \(countA) As, \(countC) Cs, \(countG) Gs, \(countT) Ts and \(countErr) errors"
        
}



