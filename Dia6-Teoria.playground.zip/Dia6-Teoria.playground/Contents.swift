import UIKit


// FUNCIONES THROWING

/*
Swift nos permite generar funciones para comprobar si hay errores con las palabras "throws" y "throw".
 */


/*
Primero se define un enum que describe el error que podemos "throw". El enum tiene que estar basado en el tipo "Error". Después podemos escribir una función para comprobar si el error existe. Por ejemplo, con una constraseña demasiado evidente.
*/

enum PasswordError: Error {
    case obvious
}


/* Ahora creamos la función que permitirá comprobar si hay algún error. La palabra "throws" se añade antes de definir el valor que retornará la función, y luego en el cuerpo de la funcion usamos "throw" para hacer call al enum */


func checkPassword (_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
    return true
}


/* Para llamar a estas funciones, es necesario usar 3 palabras clave

do --> para iniciar una sección de código que podría crear problemas
try --> antes de una función que pueda lanzar un error
catch --> para gestionar el error

Si hay un error en el bloque de "do", Swift pasa automáticamente al bloque de "catch".
 
*/

do {
    try checkPassword("password")
    print("That password is good!")
} catch {
    print("You can't use that password.")
}



// PARÁMETROS INOUT

/*
 
 Todos los parámetros que pasamos a una función en Swift son constantes. Para poder modificarlos, es necesario pasarlos como parámetros inout. Así se cambian dentro de la función y ese cambio se refleja fuera de la misma.
  
 */

func doubleInPlace(number: inout Int) {
    number *= 2
}

/*
 Es necesario crear una variable Int (no una constante, ya que no funcionan con inout pq se va a cambiar el valor). También hay que pasar el valor con un ampersand para identificar explícitamente el valor como inout.

 */

var myNum = 10
doubleInPlace(number: &myNum)

