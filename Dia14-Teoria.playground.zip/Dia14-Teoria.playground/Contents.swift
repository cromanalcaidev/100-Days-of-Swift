import UIKit

// CONSOLIDATION DAY I

// VARIABLES Y CONSTANTES


/*
 
 Todos los programas necesitan almacenar datos en algún momento y Swift lo hace de 2 maneras:
 
 - Variables: datos que pueden cambiar cuando quieramos
 
 - Constantes: datos que no van a cabmiar
 
 Tener estos dos tipos de almacenamiento permiten evitar errores y mejorar la eficiencia. Si Xcode sabe que un valor no va a cambiar nunca, puede optimizar el código para que se ejecute más rápidamente
 
 En Swift, creamos así las variables
 
 */

var name = "Tim McGraw"

/*
 Y así las actualizamos
 */

name = "Joey Tribbiani"
print(name)

/*
 Así es como creamos las constantes
 */

let nombre = "Tim McGraw"
// nombre = "Joey Tribbiani" ---> Si intentamos actualizar el valor de la constante, Xcode nos dará un error con un mensaje dde que no puede actualizar el valor porque es una constante.
print(nombre)

/*
 Las constantes son promesas que hacemos a Swift diciéndole que el contenido no va a cambiar, y si no lo cumplimos, Xcode no ejecutará el código.
 
 En general, es preferible usar constantes siempre que sea posible para hacer el código más fácil de ser leído y entendido.
 
 Por último, el nombre de las variables y las constantes debe ser único siempre. No podemos ponerle el mismo nombre a dos variables o constantes diferentes.
 
 */


// TIPOS DE DATOS SIMPLES

/*

 STRINGS: Son cadenas de texto literal. Pueden ser tan largas o cortas como queramos (incluso no tener ningún caracter). Volviendo a la variable name de antes, Swift sabe que es un string.
 
 En este caso, Swift puede inferir el tipo de dato en función del valor que le asignemos al iniciar la variable o la constante, o se lo podemos especificar.
 
 */

var nacionalidad: String
nacionalidad = "Mexicano"

/*
 
 INTEGERS: Otro tipo de datos son los números enteros, o INT, números sin decimales
 
 */

var age: Int
age = 25

/*
 
 Lo importante aquí es saber que Swift siempre quiere saber qué tipo de dato va a almacenarse en constantes y variables. Esto permite que haya seguridad de tipos. Si decimos que algo va a almacenar un string y después intentamos meter un Int, Swift no lo permitirá.
 
 */



/*
 
 FLOATS Y DOUBLES: Son en esencia lo mismo, números, pero Apple recomienda usar Double porque es más exacto porque los floats, en función de los números no decimales que tengan, se empieza a comer decimales, así que se pierde exactitud.
 
 */

var latitude: Double
latitude = -123.4123

 

/*
 
 BOOLEANOS: Es un tipo de dato absoluto: determina si algo es verdad o es mentira (true or false).
 
 */

var stayOutTooLate: Bool
stayOutTooLate = true


/*
 
 ANOTACIÓN DE TIPO
 
 Hay varias maneras de anotar el tipo de datos que va a haber en una constante o variable. Swift es capaz de identificarlo, pero en caso de que queramos especificar el tipo de dato en una var o una let, esta es la forma preferida:
 
 */

var apellido: String = "Román"



// OPERADORES

/*
 
 Los operadores son símbolos matemáticos que nos permiten hacer operaciones, como + sumar, - restar, * multiplicar, / dividir o = asignar un valor, entre otros.
 
 */

var a = 10
a = 10 + 1
a = a - 1
a = a * a

/*
 
 spoiler: esto nos dará en total 100, ya que primero sumamos 1, luego restamos 1 y luego multiplicamos por 10.
 
 Hay un método para optimizar este proceso:
 
 += sumar y asignar
 -= restar y asignar
 *= multiplicar y asignar
 /= dividir y asignar
 
 Todas estas operaciones funcionan con Int y con Double
 
 */

var b = 10
b /= 2

/*
 
 Además, tamibén podemos usar + para unir diferentes strings
 
 */


var name1 = "Tim McGraw"
var name2 = "Romeo"
var both = name1 + " and " + name2

/*
 
 % es el símbolo remainder, que lo uqe hace es dividir el número de la izquierda entre el de la derecha y devolver el remanente. Si el remanente es 0, el número de la izquieda es múltiplo del de la derecha.
 
 */

var nums = 9 % 2
print(nums)

/*
 
 OPERADORES DE COMPARACIÓN
 
 == comparamos dos valores para ver si son exactamente iguales. Solo devuelve true o false. No confundir con =, que lo que hace es decir "este valor está asignado a esta variable/constante"
 >= mayor o igual que. Solo devuelve true o false
 <= menor o igual que. Solo devuelve true o false
 != diferente de. Solo devuelve true o false
 > mayor que. Solo devuelve true o false
 < menor que. Solo devuelve true o false
 
 */



// STRING INTERPOLATION

/*
 
 Hay un método para introducir variables, constantes y código en general en un string: el string interpolation.
 
 para ello, hay que usar la fórmula: "\(your code here)"
 
 */


var name4 = "Carlos"
var saludo = "Hello, my name is \(name4)"

/*
esto facilita mucho la tarea respecto a hacerlo así
*/

var salu2 = "Hello, my name is " + name4

/*
 
 es más, se pueden añadir tantos datos y de diferentes tipos como queramos
 
 */

var edadFinal = 35
var ubicacion = 12.30921312
saludo = "Hello, my name is \(name), I'm \(edadFinal) years old and I live in \(ubicacion)"

/*
 También podemos introducir código más complejo, como operaciones, funciones, etc.
 */

saludo = "Ahora tengo \(Int(17.5 * 2)) años"
print(saludo)


// ARRAYS

/*
 
 Los arrays son colecciones de datos, normalmente del mismo tipo.
 
 Swift usa la inferencia de datos para averiguarl qué tipo de datos estamos almacenando
 
 */

var evenNumbers = [2, 4, 6, 8]
var songs = ["Beat It", "Lose Yourself to Dance", "La Revancha"]

/*
 
 Swift usa los corchetes para abrir y cerrar el array, y cada elemento está separado por una coma
 
 En cuanto a las posiciones y contarlas, Swift empieza por 0, así que el índice (posición) del primer elemento de un array siempre es 0.
 
 Para acceder al índice de un array, se usa esta escritura:
 
 */

songs[0] // Retornará "Beat It"

/*
 
 Si intentamos acceder a un índice que no existe pq nuestro array tiene menos elementos, la app crasheará.
 
 Aparte, al ser un array de 3 strings, Swift sabe que es un array de strings. Para ver el tipo de datos, se puede usar el siguiente método
 
 */


type(of: songs)

/*
 
 Esto devuelve "Array<String>.Type", lo que significa que Swift considera que "songs" es un array de strings.
 
 Si tenemos un error y añadimos un dato de otro tipo, pasará esto
 
 */

//var canciones = ["Camarera de mi amor", "Cachito", "Cuando calienta el sol", 3]
//type(of: canciones)

/*
 
 Obtenemos un error que dice "heterogeneous collection literal could ony be inferred to '[Any]'; add explicit annotation if this is el caso, entendemos".
 
 Lo que significa que Swift nos dice que parece que este array se ha creado para contener datos de diferentes tipos, y que si ese es el caso, se lo especifiquemos
 */

// var canciones = [Any] = ["Camarera de mi amor", "Cachito", "Cuando calienta el sol", 3] --> Da error, no sé por qué



//CREAR ARRAYS

/*
 
 En Swift, podemos crear arrays vacíos así
 
 */

var temazos: [String] = []

var temazos2 = [String]() // Esta forma es la preferida pq es código más corto y legible


// OPERADORES Y ARRAYS

/*
 
 El símbolo + permite unir dos arrays en uno nuevo.
 
 También se puede usar += para añadir y asignar
 
 */



var oneHitWonder = ["That thing you do"]
var oneHitWonder2 = ["Libre"]
var ambos = oneHitWonder + oneHitWonder2

ambos += ["Coches de choque"]

print(ambos)



// DICCIONARIO

/*
 
 Son una colección que permite almacenar datos en función de una key o llave. Son diferentes en los arrays en cuanto a que permiten crear una especie de clase de los datos, almacenar datos concretos. Por ejemplo, la información de una persona
 
 */


var personC = [
    "name" : "Carlos",
    "surname": "Verdejo",
    "location": "Sevilla",
    "working": "remotely"
]

/*
 
 En un array, para acceder a esta información, tendríamos que conocer cada índice. Pero con un dictionary es más fácil ir a través de la llave
 
 */


personC["name"]

/*
 Se puede almacenar muchos tipos de datos, y es común que las keys sean strings también
 */



//STATEMENTS CONDICIONALES

/*
 
 Hay veces en las que queremos ejecutar código solo si una condición concreta es verdad, y para eso podemos usar la condicionales. Hay varios tipos de condicionales:
 
 Empezamos con if / else
 
 if / else evalúa una condición y ejecuta un código si la condición de if se cumple (el código va entre llaves). Si no se cumple, ejecuta el código que va después de else (también va entre llaves).
 
 Podemos añadir else if si hay más de 2 condiciones a evaluar
 
 */

if 3 > 2 {
    print("It's true!")
} else {
    print("it's not true")
}

var action: String
var persona1 = "hater"

if persona1 == "hater" {
    action = "hate"
} else if persona1 == "player" {
    action = "play"
} else {
    action = "cruise"
}

/*
 
 Este código va a evaluar cada condición en orden y solo ejecutará uno de los bloques: persona1 solo puede ser hater, player o cualquier otra cosa, pero no todo a la vez
 
 */


/*
 
 Cómo evaluar múltiples condiciones
 
 Podemos pedirle a Swift que evalúe múltiples condiciones con el operador && (que significa "and"), pero todas tienen que ser true para ejecutar el código
 
 */


var drink: String // esto significa que es un texto
var tired = true
var old = true

if tired && old {
    drink = "infusión"
} else {
    drink = "cubata"
}


/*
 
 Como estas 2 condiciones son true, la bebida es una infusión.
 
 Swift usa algo llamado evaluación corto circuito para mejorar la performance. Si una sola de las condicioens que evalúa es falsa, no se preocupa de evaluar el resto y ahorra recursos
 
 */



/*
 
 El opuesto de true
 
 El operador ! (not) sirve para expresar lo opuesto, lo contrario, que algo no es cierto, o sea, que algo es falso.
 
 */

if !tired && !old {
    drink = "ron cola"
} else {
    drink = "cacao calentito"
}

/*
 
 En este caso, drnik solo será ron cola si ambas condiciones, tired y old, son false
 
 */




// BUCLES
 
/*
 
 Los bucles sirven para hacer tareas repetitivas tantas veces como necesitemos. Por ejemplo, esta tarea:
 
 */

print("1 x 10 is \(1 * 10)")
print("2 x 10 is \(2 * 10)")
print("3 x 10 is \(3 * 10)")
print("4 x 10 is \(4 * 10)")
print("5 x 10 is \(5 * 10)")
print("6 x 10 is \(6 * 10)")
print("7 x 10 is \(7 * 10)")
print("8 x 10 is \(8 * 10)")
print("9 x 10 is \(9 * 10)")
print("10 x 10 is \(10 * 10)")


/*
 
 Se puede simplificar con un bucle
 
 */

for i in 1...10 {
    print("\(i) x 10 is \(i*10)")
}

/*
 
 Este bucle cuenta de 1 a 10, incluyendo ambos, y en cada recuento asigna un valor a la constante i, y después ejecuta el código entre llaves.
 
 Si no necesitamos saber en qué número estamos, en vez de i o lo que sea, podemos usar un guion bajo. Por ejemplo
 
 */


var lyr = "Fakers gonna"

for _ in 1...5 {
    lyr += " fake"
}

print(lyr)

/*
 
 Usar un guion cuando no necesitamos saber en qué número está la constante i (o como queramos llamarla) sirve para que el código se ejecute más rápidamente.
 
 Una variante de estos bucles es usar ..< (lo que excluye el último número)
 
 */

print("count says:")
for num in 1..<5 {
    print(num)
}

/*
 
 Esto imprimirá hasta 4
 
 */


/*
 
 Loops y arrays
 
 Swift tiene una manera de pasar todos los elementos de un array por un bucle. Como Swift ya sabe qué tipo de información hay en el array, va a recorrer todos los elementos del array, asignar cada uno de ellos a una constante y después ejecutar un código de bloque
 
 */

var series = ["The Office", "Parks", "Friends", "The Simpsons", "Family Guy"]

for serie in series {
    print("My favorite show is \(serie)")
}


/*
 
 Para esto, también podríamos usar la estructura "for i in" y que esa constante i sea cada uno de los índices. Con este método, podemos recorrer 2 arrays a la vez
 
 */


var people = ["Pedro", "Dani", "Carlos"]
var postres = ["kito kato", "huesito", "filipino"]


for i in 0...2 {
    print("\(people[i]) se comió un \(postres[i])")
}


/*
 
 El operador ..< también es útil para trabajar con arrays pq empiezan a contar desde 0. Así que en vez de contar desde 0 y excluir 2, podemos contar desde 0 hasta y excluir el número de elementos en el array con el método .count
 
 */



var lalinenses = ["Pedro", "Dani", "Carlos"]
var comilonas = ["raxo", "cocido", "richada"]

for i in 0..<lalinenses.count {
    print("\(lalinenses[i]) se bajó él solo una bandeja de \(comilonas[i])")
}


/*
 
 Inner Loops
 
 Es posible poner loops dentro de otros loops. Con el ejemplo de antes
 
 */

for i in 0..<lalinenses.count {
    var str = "\(lalinenses[i]) se va a comer el domingo"
    
    for _ in 1...3 {
        str += " un \(comilonas[i])"
    }
    print(str)
}


/*
 
 Bucles While
 
 Otro tipo de bucle es while, que repite un código de bloque hasta que le digamos que pare (con una condición que se cumpla). Para que pare, usamos la palabra reservada "break"
 
 */

var counter = 0

while true {
    print("Counter is now \(counter)")
    counter += 1
    
    if counter == 5 {
        break
    }
    
}

/*
 
 Sin la palabra "break", tenemos un bucle infinito.
 
 El mejor uso para los bucles while es cuando usamos datos desconocidos, como al descargar datos de internet, o al leer un archivo XML... Esto es así pq solo sabemos cuándo parar el bucle después de que se haya ejecutado una serie de veces.
 
 Hay un código "opuesto" a break, que es "continue".
 
 break detiene la ejecución del código, pero "continue" solo detiene la iteración actual del bucle y regresa al bucle para seguir ejecutándolo
 
 */



var paisajes = ["montaña", "ciudad", "playa", "pueblo"]

for paisaje in paisajes {
    if paisaje == "pueblo" {
        continue
    }
    print("Mi paisaje favorito es la \(paisaje)")
}


// SWITCHES


/*
 
 Un switch/case es una manera de hacer control de flujo diferente a if / else (evita que se complique el código, lo hace más fácil de leer también)
 
 La idea básica del switch/case es que le decimos a Swift qué variable queremos que compruebe, y le damos una lista de posibles casos. Swift buscará el primer caso y ejecutará un código de bloque. Después, Swift pasa al siguiente caso + bloque de código
 
 */

let liveAlbums = 2
switch liveAlbums {
case 0:
    print("You're just starting out")

case 1:
    print("You just released iTunes Live From SoHo")

case 2:
    print("You just released Speak Now World Tour")

default:
    print("Have you done something new?")
}

/*
 
 Esto se podría haber escrito también con la estructura if/else, pero de esta manera el código queda más claro.
 
 Una ventaja de switch/case es que Swift se asegura de que el código sea exhaustivo. Es decir, si hay una posibilidad de que quede algún caso que no se haya analizado, Swift no ejecutará el código.
 
 Para ello, es necesario añadir un case default que recoja esos casos potenciales. Aunque sepamos que los datos solo van a estar en un rango concreto, apadimos default para encapsular el resto de casos.
 
 también podemos usar rangos:
 
 case 1...5
 
 o con comparaciones
 
 case night == true
 
 */
