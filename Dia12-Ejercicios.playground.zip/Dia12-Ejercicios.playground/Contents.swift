import UIKit

/*
 
 Instructions
 Your task is determine the RNA complement of a given DNA sequence.

 Both DNA and RNA strands are a sequence of nucleotides.

 The four nucleotides found in DNA are adenine (A), cytosine (C), guanine (G) and thymine (T).

 The four nucleotides found in RNA are adenine (A), cytosine (C), guanine (G) and uracil (U).

 Given a DNA strand, its transcribed RNA strand is formed by replacing each nucleotide with its complement:

 G -> C
 C -> G
 T -> A
 A -> U
 
 */



func toRNA (_ DNA: String) -> String {
    var output = ""
    
    for char in DNA {
        switch char {
        case "G":
            output += "C"
        case "C":
            output += "G"
        case "T":
            output += "A"
        case "A":
            output += "U"
        default:
            output += "This ain't no DNA sequence"
        }
    }
    
    return output
}


toRNA("GCTA")

print(toRNA("GCTA"))


/*
 
 Find the difference between the square of the sum and the sum of the squares of the first N natural numbers.

 The square of the sum of the first ten natural numbers is (1 + 2 + ... + 10)² = 55² = 3025.

 The sum of the squares of the first ten natural numbers is 1² + 2² + ... + 10² = 385.

 Hence the difference between the square of the sum of the first ten natural numbers and the sum of the squares of the first ten natural numbers is 3025 - 385 = 2640.

 You are not expected to discover an efficient solution to this yourself from first principles; research is allowed, indeed, encouraged. Finding the best algorithm for the problem is a key skill in software engineering.
 
 */


class Squares {
    
    var n1: Int
    
    init (n1: Int) {
        self.n1 = n1
    }
    
    func returnSquaredDiff() -> Int {
        
        func squaredSum() -> Int {
            var output = 0
            for i in 1...self.n1 {
                output += (i*i)
            }
            print(output)
            return output
        }
        
        func sumSquared() -> Int {
            var sum = 0
            for i in 1...self.n1 {
                sum += i
            }
            let output = sum*sum
            print(output)
            return output
        }
        
        let squaredDiff = sumSquared() - squaredSum()
        
        return squaredDiff
    }
    
}


/*
 
 Instructions
 Given an age in seconds, calculate how old someone would be on:

 Mercury: orbital period 0.2408467 Earth years
 Venus: orbital period 0.61519726 Earth years
 Earth: orbital period 1.0 Earth years, 365.25 Earth days, or 31557600 seconds
 Mars: orbital period 1.8808158 Earth years
 Jupiter: orbital period 11.862615 Earth years
 Saturn: orbital period 29.447498 Earth years
 Uranus: orbital period 84.016846 Earth years
 Neptune: orbital period 164.79132 Earth years
 So if you were told someone were 1,000,000,000 seconds old, you should be able to say that they're 31.69 Earth-years old.

 If you're wondering why Pluto didn't make the cut, go watch this YouTube video.

 Note: The actual length of one complete orbit of the Earth around the sun is closer to 365.256 days (1 sidereal year). The Gregorian calendar has, on average, 365.2425 days. While not entirely accurate, 365.25 is the value used in this exercise. See Year on Wikipedia for more ways to measure a year.
 
 */


class SpaceAge {
    // Write your code for the 'SpaceAge' exercise in this file.
    
    let seconds: Double
    let choosePlanet: String
    
    init (seconds: Double, choosePlanet: String) {
        self.seconds = seconds
        self.choosePlanet = choosePlanet
    }
    
    func secondsToYears() -> Double {
        
        switch choosePlanet {
        case "Earth":
            return (((self.seconds / 60.00) / 60.00) / 24.00) / 365.25
        case "Mercury":
            return ((((self.seconds / 60.00) / 60.00) / 24.00) / 365.25) * 0.2408467
        case "Venus":
            return ((((self.seconds / 60.00) / 60.00) / 24.00) / 365.25) * 0.61519726
        case "Mars":
            return ((((self.seconds / 60.00) / 60.00) / 24.00) / 365.25) * 1.8808158
        case "Jupiter":
            return ((((self.seconds / 60.00) / 60.00) / 24.00) / 365.25) * 11.862615
        case "Saturn":
            return ((((self.seconds / 60.00) / 60.00) / 24.00) / 365.25) * 29.447498
        case "Uranus":
            return ((((self.seconds / 60.00) / 60.00) / 24.00) / 365.25) * 84.016846
        case "Neptune":
            return ((((self.seconds / 60.00) / 60.00) / 24.00) / 365.25) * 164.79132
        default:
            return 0.0
        }
    }
}

/*
 
 Your task is to write the code that calculates the energy points that get awarded to players when they complete a level.

 The points awarded depend on two things:

 - The level (a number) that the player completed.
 - The base value of each magical item collected by the player during that level.
 
 The energy points are awarded according to the following rules:

 - For each magical item, take the base value and find all the multiples of that value that are less than the level number.
 - Combine the sets of numbers.
 - Remove any duplicates.
 - Calculate the sum of all the numbers that are left.
 
 Let's look at an example:

 The player completed level 20 and found two magical items with base values of 3 and 5.

 To calculate the energy points earned by the player, we need to find all the unique multiples of these base values that are less than level 20.

 - Multiples of 3 less than 20: {3, 6, 9, 12, 15, 18}
 - Multiples of 5 less than 20: {5, 10, 15}
 - Combine the sets and remove duplicates: {3, 5, 6, 9, 10, 12, 15, 18}
 - Sum the unique multiples: 3 + 5 + 6 + 9 + 10 + 12 + 15 + 18 = 78
 - Therefore, the player earns 78 energy points for completing level 20 and finding the two magical items with base values of 3 and 5.

 
 */


func toLimit(_ limit: Int, inMultiples: [Int]) -> Int {
  // Write your code for the 'SumOfMultiples' exercise in this method.
    var newSet = Set<Int>()
    var points = 0
    
    for object in inMultiples {
        for i in 1...limit {
            if object*i >= limit {
                break
            } else {
                newSet.insert(object*i)
            }
            }
        }
    
    for element in newSet {
        points += element
    }
    
    return points
}

