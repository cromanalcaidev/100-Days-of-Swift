import UIKit


// Write a Swift program to compute the sum of the two integers. If the values are equal return the triple their sum.

func suma (n1: Int, n2: Int) -> Int {
    
    if n1 == n2 {
        return ((n1+n2) * 3)
    } else {
        return n1 + n2
    }
}


// Write a Swift program to compute and return the absolute difference of n and 51, if n is over 51 return double the absolute difference

func over51 (n1: Int) -> Int {
    if n1 > 51 {
        return (n1 - 51) * 2
    } else {
        return 51 - n1
    }
}


// Write a Swift program that accept two integer values and return true if one of them is 20 or if their sum is 20.

func isIt20 (n1: Int, n2: Int) -> Bool {
    if n1 + n2 == 20 {
        return true
    } else if n1 == 20 || n2 == 20 {
        return true
    } else {
        return false
    }
}


// Write a Swift program to accept two integer values and false if one is negative and one is positive. Return true only if both are negative.

func isNegative (n1: Int, n2: Int) -> Bool {
    if n1 < 0 || n2 < 0 {
        return false
    } else if n1 >= 0 && n2 >= 0 {
        return false
    } else {
        return true
    }
}


// Write a Swift program to remove a character at specified index of a given non-empty string. The value of the specified index will be in the range 0..str.length()-1 inclusive.


func removeChar (givenStr: String, indexToRemove: Int) -> String {
    var result = ""
    for (index, char) in givenStr.enumerated() {
        if index != indexToRemove {
            result.append(char)
        }
    }
    return result
}

print(removeChar(givenStr: "Hola, mi amor", indexToRemove: 4))
