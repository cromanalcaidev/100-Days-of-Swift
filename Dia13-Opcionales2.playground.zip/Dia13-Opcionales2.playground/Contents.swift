import UIKit

// OPTIONAL TRY


/*
 
 Cuando estábamos con las funciones throw, teníamos un código parecido a este
 
 */


enum PasswordError: Error {
    case obvious
}

func checkPassword(_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
    return true
}
do {
    try checkPassword("password")
    print("That password is good!")
} catch {
    print("You can't use that password.")
}

/*
 Este código es una función throwing que usa do, try y catch para gestionar los errores
 
 Hya dos alternativas a try:
 
 - try?
 
Que cambia la función throwing a función que retorna un opcional. Si la función tira un error, devolverá nil como resultado. De lo contrario, retornará el valor envuelto como una opcional
 
 */
 
if let result = try? checkPassword("password") {
    print("Result was \(result)")
} else {
    print("D'oh!")
}

 /*
 - try!
  
  Solo usarlo en caso de saber que la función no va a fallar. Si la función tira un error, el código crasheará
 
 */

try! checkPassword("sekrit")
print("OK!")


// FAILABLE INITIALIZERS

/*
 Recordemos este código
 */

let str = "5"
let num = Int(str)

/*
 Esto convierte un string en ujn Int, pero como es posible pasar cualquier string, el Int es un Int opcional
 
 A esto se le llama un inicializador fallable: puede o no funcionar. Para escribirlo en structs y clases, se puede usar init?() en vez de init(), y retornar nil si algo va mal. El valor de retorno será un opcional para desenvolver como queramos.
 
 Como ejemplo, podemos crear un struct Person que debe crearse usando un ID de 9 letras. Si se pasa cualquier otra cosa que no sea exactamente 9 letras, retornaremos nil. De lo contrario, el código se ejecutará normalmente
 */


struct Person {
    var id: String
    init?(id: String) {
        if id.count == 9 {
            self.id = id
        } else {
            return nil
        }
    }
}

/*
 A Double(unString) le pasa lo mismo que a Int(unString), pero con Bool(unString) pasa algo diferente: busca exactamente true o false, o de lo contrario retorna nil.
 */


//TYPECASTING

/*
 Swift siempre necesita conocer el tipo de cada una de lavariables, pero muchas veces nosotros sabemos más que swift. Por ejemplo, mira estas clases
 */


class Animal {}
class Fish: {}
class Dog: Animal {
    func makeNoise() {
        print("Woof!")
    }
}

/*
 Podemos crear un par de Fish y Dog, y añadirlos a un array así:
 */


let pets = [Fish(), Dog(), Fish(), Dog()]

/*
 Swift puede ver que Fish y Dog heredan de la clase Animal, así que usa la inferencia de tipos para hacer de pets un array de Animal.
 
 Se queremos hacer un bucle para recorrer el array pets y pedir a los perros que ladren, necesitamos hacer typecast: Swift tiene que comprobar si cada elemento de pet es un bojeto Dog, y si lo es, podemos llamar a la función makeNoise()
 
 Esto usa la nueva keyword "as?", que retorna un opcional: será nil si el typecast falla, o un tipo convertido en caso contrario.
 
 Así escribiríamos el bucle en Swift
 */

for pet in pets {
    if let dog = pet as? Dog {
        dog.makeNoise()
    }
}


